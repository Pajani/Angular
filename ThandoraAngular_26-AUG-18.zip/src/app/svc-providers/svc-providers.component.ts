import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-svc-providers',
  templateUrl: './svc-providers.component.html',
  styleUrls: ['./svc-providers.component.scss']
})
export class SvcProvidersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
