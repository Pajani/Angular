import { Component, OnInit } from '@angular/core';

import {Observable} from 'rxjs';
import {AngularFireAuth} from 'angularfire2/auth'
import * as firebase from 'firebase';
import { AfService } from '../provider/af.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})

 

export class SigninComponent implements OnInit {

  public user:any;
  public error:any;
  userName:string;
  public isSignedIn:boolean ;
  isSignedOut: boolean= true;
  public a:number =4;
  public b:number=5
  
  issubscribed : string = 'true';
  isUnsubscribed :string = 'true';

  constructor(public afs: AfService  ) {
    //this.isSignedIn = this.afs.isLoggedin;

    this.afs.user.subscribe((auth)=>{ console.log(auth);

      if (auth==null)
      {
        this.isSignedIn=false;
      }
      else
      {this.isSignedIn=true;}
    })
        //this.user = af.authState;
        //console.log(this.user);
        //this.af.auth.onAuthStateChanged(this.handleAuthStateChanged);
   }
  ngOnInit() {
    //this.afAuth.isLoggedIn();
    
    //console.log(this.afAuth.authtoken) ;
    
    /*firebase.auth().onAuthStateChanged((auth) => {
      
      if( auth)
      {
          this.user=auth;
          this.isSignedIn=true;
      }
      else
      {
          this.user = auth;
          this.isSignedIn=false;
      }
      
      this.isSignedIn=true})
      */

    // this.af.auth.onAuthStateChanged(this.handleAuthStateChanged);

       /*this.af.auth.onAuthStateChanged(auth =>{
     auth.getIdToken(true) 
     .then((token)=>{this.authtoken=token;this.isSignedon=true;console.log('my testmessage: '+this.authtoken)})
       .catch(()=>console.log('user not logged in'))
       
    });*/

      //console.log('sigin loading'+ this.isSignedIn) ;
    /*this.af.auth
    .onAuthStateChanged()
              if(user)
              {//this.user=user;
               this.isSignedIn=true;
              }
              else{
                this.error=user;
                this.isSignedIn=false;
              }
            }
          )
  */
  
  }

  buttonStatus()
  {

    //this.afAuth.isLoggedIn();

    //this.isSignedOut = (this.isSignedIn==true)?false:true;
    
  }
  login()
  {
    //const provider = new firebase.auth.GoogleAuthProvider();
    this.afs.loginWithGoogle();
    //this.afs.auth.signInWithPopup(provider).then((auth)=> {this.af.auth.onAuthStateChanged(this.handleAuthStateChanged);})
    //.catch((err)=>{this.error=err});
   
   
    //this.afAuth.loginWithGoogle();
  }

  handleAuthStateChanged(user)
  {
    if(user)
    {console.log(user)
      this.isSignedIn=true;
    }
    else
    {console.log('no user logged')
      this.isSignedIn=false;
    }
    //this.user = user;
  }

  logout()
  {
    this.afs.logout();
   // this.afAuth.user=null;
  }

  notifyme()
  {
    //this.afAuth.getcurrentuser().subscribe(x => this.isSignedIn=x);
   //console.log(this.isSignedIn); 
    //this.afAuth.notifyme();
  }

  unsubscribe()
  {
    //this.afAuth.unsubscribe();
  }


  myfunction(){
    //this.getcurrentUser().subscribe(x => this.isSignedIn=x);
  // console.log("myfunction " + this.isSignedIn);
  }
  
  /*getcurrentUser():Observable<boolean>
  {return new Observable<boolean>((res,rej) => {
     
     if (this.a<this.b) 
     {  res( true);
     }
     else
     {  rej(false);}
  })
 }*/
}
